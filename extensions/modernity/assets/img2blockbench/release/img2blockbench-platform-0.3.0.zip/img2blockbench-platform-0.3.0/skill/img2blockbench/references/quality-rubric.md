# Quality rubric

## Contents

1. [Reference](#reference)
2. [Geometry](#geometry)
3. [Texture](#texture)
4. [Rigging](#rigging)
5. [Required renders](#required-renders)
6. [Approval](#approval)

## Reference

- The subject already uses Minecraft-native cuboid forms and square-pixel
  materials.
- Show the full subject without severe occlusion.
- Prefer a neutral pose and weak perspective.
- Record ambiguous depth, hidden limbs, and unseen markings.
- For a named production subject, cite any official turnarounds or gameplay
  frames used to resolve topology, including exact video timestamps.
- Request another image when ambiguity controls the subject's identity.
- Reject photographs and smooth organic illustrations from Lane 1 until they
  are restyled as Minecraft concepts.
- Photographs may instead use the explicitly single-view photo-relief route.
  Judge its source-facing silhouette and texture separately from hidden depth.
- On a complex background, inspect the supplied or automatic mask at full
  subject extent. High texture PSNR on a small retained fragment is a failure.

## Geometry

- Every cuboid has a semantic purpose.
- Medium mobs normally use 15–35 cuboids.
- Paired anatomy is symmetric unless intentionally different.
- Jointed segments share pivots and overlap slightly.
- No floating hands, feet, jaws, wings, or tail segments.
- No geometry is split merely because texture color changes.
- The silhouette reads correctly from front, side, and isometric views.
- For a long thin reconstruction, endpoints remain connected and its exported
  thickness never rounds to zero. Geometry precision and texture density are
  evaluated independently.
- For a mesh reconstruction, cleanup uses 6-neighbor connectivity and reports
  every removed component. Detached identity features are retained even when
  they are not part of the largest component.
- Adaptive cuboids stay within the declared budget and are compared with the
  ray-derived source surface using 3D voxel overlap, tolerant surface F1,
  three orthographic silhouettes, and bidirectional depth error.

## Texture

- One texel density is used across all faces.
- Pixel patterns are nearest-neighbor; palette reduction introduces no noise.
- Unobserved material defaults are solid; random dither is never used as a
  generic realism or weathering pass.
- Eyes, nostrils, mouth lines, markings, and seams are texture pixels.
- Both face sides point toward the same anatomical front.
- Atlas gutters do not bleed unrelated colors.
- Identity features survive palette reduction.
- Mesh colors come from sampled UV textures, vertex colors, face colors, or a
  recorded material fallback; inspect the palette and rendered atlas.
- For a calibrated reference bake, every transferred texel is inside the
  supplied foreground mask and belongs to the frontmost cuboid face in that
  fixed camera. Inspect the recorded per-view and per-face coverage.
- Unobserved surfaces use an explicitly disclosed solid fallback. Do not call
  mirrored, filled, or procedural pixels observed source texture.
- Minecraft-styled reference output uses a bounded palette and low texel
  density without dithering. Logos, seams, wear, and other flat identity marks
  come from the source-guided patch or an audited decal, not random noise or
  extra cuboids. Literal source projection is opt-in and must be labeled.

## Rigging

- Exactly one root bone exists.
- Every cube belongs to an existing bone.
- Pivots sit at anatomical joints.
- Parent chains follow the creature's actual articulation.
- Collision width, height, and eye height are plausible gameplay values.
- A wearable machine keeps preview-occupant bones removable and never parents
  retained shell bones beneath them.
- Player-fit exports preserve an open body cavity plus named harness, control,
  and foot-restraint anchors; inspect both occupied and empty-shell renders.

## Required renders

Inspect:

- left and right full body;
- front and back;
- top and bottom for every claimed full-volume model;
- at least one isometric or oblique view;
- left and right head close-ups;
- close-ups of connected joints;
- animation playback when animations exist.

Structural audits cannot approve anatomical direction, resemblance, expression,
or animation quality.

For Route 1, approve the cuboid fit only when its multi-angle manifest is
complete, all retained 6-connected components are represented, and its
source-relative anti-pancake gate passes. Verify fitted connectivity is
one-to-one with retained source components, not merely that every source label
received a cuboid. A thin source is not itself a defect; the gate measures both
lost thickness and excessive depth/volume inflation relative to the source
mesh. The delivery bundle must contain hash-verified localized copies of the
review manifest and all of its required images.

For agent-authored semantic models, run the generic model-only review and
inspect all seven views plus the all-angle sheet. Pixel-distinct hashes can
surface suspiciously repeated views, but legitimate symmetry may also produce
duplicates; treat that signal as a warning rather than proof of collapse.

## Approval

Approve only when:

- the subject is immediately recognizable;
- both sides of the face agree;
- no joint visibly detaches;
- the model looks Minecraft-native rather than voxelized;
- all required views were inspected;
- the generated audit reports no errors.

For photo reliefs, approval is scoped to source-facing resemblance unless
additional views or a source mesh establish hidden geometry. Also inspect the
segmentation mask, deterministic isometric render, and reprojection metrics;
none of those measurements replaces visual comparison with the reference.
For symmetric depth fields, verify that the mask retains thin identity parts,
the maximum and minimum thickness regions are plausible, and the isometric
view reads as one coherent volume rather than stacked disconnected sheets.
For global principal-axis reliefs, also inspect silhouette IoU and recall, the
true depth profile, pointed endpoints, perpendicular attachments, and internal
seams. PCA alignment can reduce cuboid count but cannot prove semantic part
orientation or hidden-side correctness.
For ray-voxel meshes, inspect all six canonical sides plus an isometric view,
confirm every meaningful component survived cleanup, and investigate odd
parity rays rather than silently treating an open mesh as solid. Approval is
for static geometry only when the output has one nonsemantic root bone.
